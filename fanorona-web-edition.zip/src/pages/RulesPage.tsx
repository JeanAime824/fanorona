/**
 * @file RulesPage.tsx
 * Complete illustrated guide and Malagasy rules reference for Fanorona.
 */

import {
  ArrowDownLeft,
  ArrowUpRight,
  BookOpen,
  CheckCircle2,
  HelpCircle,
  Repeat,
  ShieldAlert,
  Swords,
} from "lucide-react";
import React from "react";
import { Card } from "../components/ui/Card";

export const RulesPage: React.FC = () => {
  return (
    <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8 text-[#e0cfbe]">
      {/* Hero Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#382215] border border-[#5a3821] text-xs text-[#f5a164] font-semibold">
          <BookOpen className="w-3.5 h-3.5 text-[#d87a38]" />
          <span>Guide officiel & Règles traditionnelles</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold font-display text-[#f5ede2]">
          Les Règles du Fanorona
        </h1>
        <p className="text-sm sm:text-base text-[#a89582] max-w-2xl mx-auto">
          Fanoron-tsivy (le grand Fanorona à 9 colonnes et 5 rangées) est un jeu de stratégie combinatoire abstrait d'une rare élégance tactique, originaire de Madagascar.
        </p>
      </div>

      {/* Grid of Rule Concepts */}
      <div className="space-y-6">
        {/* Section 1: Le Plateau et les Intersections */}
        <Card variant="elevated" className="space-y-3">
          <div className="flex items-center gap-3 text-lg font-bold font-display text-[#f5ede2]">
            <div className="w-8 h-8 rounded-xl bg-[#362114] border border-[#5a3821] flex items-center justify-center text-[#d87a38] text-sm">
              1
            </div>
            <span>Le Plateau (Fanoron-tsivy)</span>
          </div>
          <p className="text-sm leading-relaxed text-[#c4b19e]">
            Le jeu se déroule sur une grille de <strong>9 colonnes sur 5 rangées</strong> formant <strong>45 intersections</strong> reliées par des lignes horizontales, verticales et diagonales.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
            <div className="p-3 rounded-xl bg-[#1a100a] border border-[#382315]">
              <strong className="text-[#f5a164] block mb-1">Intersections Fortes (25 points)</strong>
              Où la somme (rangée + colonne) est paire. La pièce peut s'y déplacer dans <strong>8 directions</strong> (4 orthogonales + 4 diagonales). Le centre (E3) est une intersection forte.
            </div>
            <div className="p-3 rounded-xl bg-[#1a100a] border border-[#382315]">
              <strong className="text-[#f5a164] block mb-1">Intersections Faibles (20 points)</strong>
              Où la somme est impaire. La pièce ne peut s'y déplacer que dans <strong>4 directions orthogonales</strong> (haut, bas, gauche, droite).
            </div>
          </div>
        </Card>

        {/* Section 2: Disposition initiale */}
        <Card variant="elevated" className="space-y-3">
          <div className="flex items-center gap-3 text-lg font-bold font-display text-[#f5ede2]">
            <div className="w-8 h-8 rounded-xl bg-[#362114] border border-[#5a3821] flex items-center justify-center text-[#d87a38] text-sm">
              2
            </div>
            <span>Disposition initiale (Vava)</span>
          </div>
          <p className="text-sm leading-relaxed text-[#c4b19e]">
            Le plateau compte <strong>44 pièces</strong> au départ : 22 blanches et 22 noires.
          </p>
          <ul className="text-xs space-y-1.5 list-disc list-inside text-[#bda997] pl-1">
            <li>Les deux rangées supérieures sont entièrement occupées par les <strong>Noirs</strong>.</li>
            <li>Les deux rangées inférieures sont entièrement occupées par les <strong>Blancs</strong>.</li>
            <li>
              La rangée médiane alterne : <em>Noir, Blanc, Noir, Blanc, <strong>VIDE (Centre E3)</strong>, Blanc, Noir, Blanc, Noir</em>.
            </li>
            <li>Les <strong>Blancs jouent toujours le premier coup</strong>.</li>
          </ul>
        </Card>

        {/* Section 3: Mécanismes de Capture : Approche vs Éloignement */}
        <Card variant="accent" className="space-y-4">
          <div className="flex items-center gap-3 text-lg font-bold font-display text-[#f5ede2]">
            <div className="w-8 h-8 rounded-xl bg-[#b8652e]/30 border border-[#d87a38]/40 flex items-center justify-center text-[#f5a164] text-sm">
              3
            </div>
            <span>La Révolution du Fanorona : Deux modes de capture</span>
          </div>
          <p className="text-sm leading-relaxed text-[#c4b19e]">
            Contrairement aux Dames ou aux Échecs où l'on capture en sautant ou en remplaçant une pièce, au Fanorona on capture <strong>par contact à distance</strong> le long des lignes de déplacement.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
            {/* Tomboky */}
            <div className="p-4 rounded-xl bg-[#1c110a] border border-[#4d2f1b] space-y-2">
              <div className="flex items-center gap-2 text-[#f5a164] font-bold text-sm">
                <ArrowUpRight className="w-4 h-4" />
                <span>Capture par Approche (Tomboky)</span>
              </div>
              <p className="text-xs text-[#a89582] leading-relaxed">
                Votre pièce avance d'une intersection adjacente vers une intersection vide qui entre directement en contact avec une pièce ennemie alignée. <strong>La pièce ennemie et toute la ligne ininterrompue de pièces ennemies situées directement derrière elle sont capturées et retirées du plateau.</strong>
              </p>
            </div>

            {/* Faly */}
            <div className="p-4 rounded-xl bg-[#1c110a] border border-[#4d2f1b] space-y-2">
              <div className="flex items-center gap-2 text-[#f5a164] font-bold text-sm">
                <ArrowDownLeft className="w-4 h-4" />
                <span>Capture par Éloignement (Faly)</span>
              </div>
              <p className="text-xs text-[#a89582] leading-relaxed">
                Votre pièce est en contact avec une pièce ennemie et se déplace dans la direction opposée vers une intersection vide adjacente. <strong>La pièce ennemie dont vous vous éloignez et toute la ligne ininterrompue de pièces ennemies directement collées derrière elle sont capturées.</strong>
              </p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-[#26170e] border border-[#52331c] text-xs text-[#d8cab7] flex items-start gap-2.5">
            <HelpCircle className="w-4 h-4 text-[#d87a38] shrink-0 mt-0.5" />
            <span>
              <strong>Cas de choix simultané :</strong> Si un déplacement produit à la fois une capture par Approche devant et par Éloignement derrière, le joueur choisit obligatoirement l'une des deux captures (il ne peut pas capturer les deux en un seul coup).
            </span>
          </div>
        </Card>

        {/* Section 4: Enchaînements de captures (Combo) */}
        <Card variant="elevated" className="space-y-3">
          <div className="flex items-center gap-3 text-lg font-bold font-display text-[#f5ede2]">
            <div className="w-8 h-8 rounded-xl bg-[#362114] border border-[#5a3821] flex items-center justify-center text-[#d87a38] text-sm">
              4
            </div>
            <span>Enchaînements de Captures (Séquences multiples)</span>
          </div>
          <p className="text-sm leading-relaxed text-[#c4b19e]">
            Après une capture réussie, si la même pièce peut immédiatement exécuter une nouvelle capture depuis sa nouvelle position, le joueur peut continuer son tour.
          </p>
          <div className="space-y-2 text-xs text-[#a89582]">
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#10b981] shrink-0 mt-0.5" />
              <span><strong>Même pièce :</strong> Seule la pièce ayant initié le coup peut continuer la chaîne.</span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#10b981] shrink-0 mt-0.5" />
              <span><strong>Changement de direction obligatoire :</strong> Le coup suivant ne peut pas continuer dans la même direction vectorielle que le coup précédent.</span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#10b981] shrink-0 mt-0.5" />
              <span><strong>Pas de retour :</strong> La pièce ne peut pas repasser par une intersection déjà visitée lors du même tour.</span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#10b981] shrink-0 mt-0.5" />
              <span><strong>Arrêt volontaire :</strong> Contrairement au premier coup qui est obligatoire si une capture existe, le joueur peut décider d'interrompre son enchaînement à tout moment via le bouton « Terminer le tour ».</span>
            </div>
          </div>
        </Card>

        {/* Section 5: Capture Obligatoire */}
        <Card variant="elevated" className="space-y-3">
          <div className="flex items-center gap-3 text-lg font-bold font-display text-[#f5ede2]">
            <ShieldAlert className="w-5 h-5 text-[#f59e0b]" />
            <span>Règle de Capture Obligatoire</span>
          </div>
          <p className="text-sm leading-relaxed text-[#c4b19e]">
            Si au début d'un tour, un ou plusieurs coups avec capture sont possibles sur le plateau, <strong>le joueur est obligé d'effectuer une capture</strong>. Il ne peut pas jouer un simple déplacement sans capture (coup <em>Paika</em>) tant qu'une capture est disponible.
          </p>
        </Card>

        {/* Section 6: Victoire */}
        <Card variant="elevated" className="space-y-3">
          <div className="flex items-center gap-3 text-lg font-bold font-display text-[#f5ede2]">
            <Swords className="w-5 h-5 text-[#d87a38]" />
            <span>Fin de Partie et Victoire</span>
          </div>
          <p className="text-sm leading-relaxed text-[#c4b19e]">
            La partie se termine par la victoire d'un joueur dans deux situations :
          </p>
          <ul className="text-xs space-y-1.5 list-disc list-inside text-[#bda997] pl-1">
            <li><strong>Élimination totale :</strong> Toutes les pièces de l'adversaire ont été capturées (0 pièce restante).</li>
            <li><strong>Blocage complet :</strong> L'adversaire a encore des pièces, mais aucune d'entre elles ne peut effectuer de déplacement légal.</li>
          </ul>
        </Card>
      </div>
    </div>
  );
};
