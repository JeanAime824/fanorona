/**
 * @file SettingsPage.tsx
 * Configuration panel for audio, visual aids, default AI difficulty, and match statistics.
 */

import {
  Award,
  BarChart2,
  Bell,
  Eye,
  RotateCcw,
  Settings as SettingsIcon,
  Sliders,
  Volume2,
} from "lucide-react";
import React, { useState } from "react";
import { Button } from "../components/ui/Button";
import { Card } from "../components/ui/Card";
import { Modal } from "../components/ui/Modal";
import { AiDifficulty, GameSettings, GameStats } from "../game/types/gameTypes";
import { DEFAULT_STATS, storageService } from "../services/storage/storageService";

export interface SettingsPageProps {
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
  stats: GameStats;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  settings,
  onUpdateSettings,
  stats,
}) => {
  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [currentStats, setCurrentStats] = useState<GameStats>(stats);

  const winRate =
    currentStats.gamesPlayed > 0
      ? Math.round((currentStats.gamesWon / currentStats.gamesPlayed) * 100)
      : 0;

  const handleResetStats = () => {
    storageService.saveStats(DEFAULT_STATS);
    setCurrentStats(DEFAULT_STATS);
    setIsResetConfirmOpen(false);
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8 text-[#e0cfbe]">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#382215] border border-[#5a3821] text-xs text-[#f5a164] font-semibold">
          <SettingsIcon className="w-3.5 h-3.5 text-[#d87a38]" />
          <span>Préférences & Profil</span>
        </div>
        <h1 className="text-3xl font-extrabold font-display text-[#f5ede2]">
          Paramètres & Statistiques
        </h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        {/* Settings Column */}
        <div className="space-y-4">
          <h2 className="text-base font-bold font-display text-[#f5ede2] flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#d87a38]" />
            <span>Options de jeu</span>
          </h2>

          <Card variant="elevated" className="space-y-4">
            {/* Sound Toggle */}
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-semibold text-[#f5ede2] flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-[#d87a38]" />
                  <span>Effets sonores</span>
                </div>
                <div className="text-xs text-[#8a7260]">
                  Bruits de pierres, capture et victoire
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.soundEnabled}
                onChange={(e) => onUpdateSettings({ soundEnabled: e.target.checked })}
                className="w-5 h-5 accent-[#d87a38] cursor-pointer"
              />
            </div>

            <div className="border-t border-[#331f13]" />

            {/* Possible Moves Highlight */}
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-semibold text-[#f5ede2] flex items-center gap-2">
                  <Eye className="w-4 h-4 text-[#d87a38]" />
                  <span>Guides visuels des coups</span>
                </div>
                <div className="text-xs text-[#8a7260]">
                  Surligner les destinations autorisées
                </div>
              </div>
              <input
                type="checkbox"
                checked={settings.showPossibleMoves}
                onChange={(e) =>
                  onUpdateSettings({ showPossibleMoves: e.target.checked })
                }
                className="w-5 h-5 accent-[#d87a38] cursor-pointer"
              />
            </div>

            <div className="border-t border-[#331f13]" />

            {/* Default AI Difficulty */}
            <div>
              <label className="block text-sm font-semibold text-[#f5ede2] mb-2">
                Difficulté par défaut de l'IA
              </label>
              <div className="grid grid-cols-3 gap-2">
                {(["easy", "medium", "hard"] as AiDifficulty[]).map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => onUpdateSettings({ aiDifficulty: d })}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold cursor-pointer transition-all ${
                      settings.aiDifficulty === d
                        ? "bg-[#382215] border-[#d87a38] text-[#f5ede2] shadow-sm"
                        : "bg-[#1a100a] border-[#382315] text-[#8a7260] hover:text-[#e0cfbe]"
                    }`}
                  >
                    {d === "easy" ? "Facile" : d === "medium" ? "Moyen" : "Difficile"}
                  </button>
                ))}
              </div>
            </div>
          </Card>
        </div>

        {/* Statistics Column */}
        <div className="space-y-4">
          <h2 className="text-base font-bold font-display text-[#f5ede2] flex items-center gap-2">
            <BarChart2 className="w-4 h-4 text-[#d87a38]" />
            <span>Statistiques locales</span>
          </h2>

          <Card variant="elevated" className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-[#1a100a] border border-[#382315]">
                <div className="text-xs text-[#8a7260]">Parties jouées</div>
                <div className="text-2xl font-bold text-[#f5ede2] font-display">
                  {currentStats.gamesPlayed}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#1a100a] border border-[#382315]">
                <div className="text-xs text-[#8a7260]">Taux de victoires</div>
                <div className="text-2xl font-bold text-[#86efac] font-display">
                  {winRate}%
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#1a100a] border border-[#382315]">
                <div className="text-xs text-[#8a7260]">Victoires</div>
                <div className="text-xl font-bold text-[#f5ede2] font-display">
                  {currentStats.gamesWon}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-[#1a100a] border border-[#382315]">
                <div className="text-xs text-[#8a7260]">Total captures</div>
                <div className="text-xl font-bold text-[#f5a164] font-display">
                  {currentStats.totalCaptures}
                </div>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsResetConfirmOpen(true)}
                icon={<RotateCcw className="w-3.5 h-3.5" />}
              >
                Réinitialiser les stats
              </Button>
            </div>
          </Card>
        </div>
      </div>

      {/* Confirmation modal for stats reset */}
      <Modal
        isOpen={isResetConfirmOpen}
        onClose={() => setIsResetConfirmOpen(false)}
        title="Réinitialiser les statistiques ?"
        maxWidth="sm"
      >
        <div className="space-y-4 text-sm text-[#d8cab7]">
          <p>
            Cette action effacera définitivement l'historique de vos victoires, défaites et captures enregistrées sur cet appareil.
          </p>
          <div className="flex justify-end gap-3 pt-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsResetConfirmOpen(false)}
            >
              Annuler
            </Button>
            <Button
              variant="danger"
              size="sm"
              onClick={handleResetStats}
            >
              Effacer les données
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
