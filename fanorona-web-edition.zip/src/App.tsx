/**
 * @file App.tsx
 * Master application layout and view router for Fanorona Web Edition.
 */

import React, { useState } from "react";
import { Navbar, NavTab } from "./components/layout/Navbar";
import { useFanoronaGame } from "./hooks/useFanoronaGame";
import { GamePage } from "./pages/GamePage";
import { HistoryPage } from "./pages/HistoryPage";
import { RulesPage } from "./pages/RulesPage";
import { SettingsPage } from "./pages/SettingsPage";

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavTab>("game");
  const { settings, updateSettings, stats } = useFanoronaGame();

  const handleToggleSound = () => {
    updateSettings({ soundEnabled: !settings.soundEnabled });
  };

  return (
    <div className="min-h-screen bg-[#160c07] text-[#f4efe8] flex flex-col selection:bg-[#d87a38]/30 selection:text-[#fff8f2]">
      {/* Top Navbar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        soundEnabled={settings.soundEnabled}
        onToggleSound={handleToggleSound}
      />

      {/* Main Tab Content */}
      <main className="flex-1 flex flex-col">
        {currentTab === "game" && <GamePage />}
        {currentTab === "rules" && <RulesPage />}
        {currentTab === "history" && <HistoryPage />}
        {currentTab === "settings" && (
          <SettingsPage
            settings={settings}
            onUpdateSettings={updateSettings}
            stats={stats}
          />
        )}
      </main>

      {/* Cultural Footer */}
      <footer className="w-full border-t border-[#3b2517] bg-[#140b06] py-6 px-4 text-center text-xs text-[#8a7260]">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-[#b89578] tracking-wider uppercase">
              Fanorona
            </span>
            <span>—</span>
            <span>Le jeu traditionnel de Madagascar</span>
          </div>

          <div className="flex items-center gap-4 text-[#755e4e]">
            <button
              onClick={() => setCurrentTab("rules")}
              className="hover:text-[#d87a38] transition-colors cursor-pointer"
            >
              Règles
            </button>
            <button
              onClick={() => setCurrentTab("history")}
              className="hover:text-[#d87a38] transition-colors cursor-pointer"
            >
              Histoire
            </button>
            <button
              onClick={() => setCurrentTab("settings")}
              className="hover:text-[#d87a38] transition-colors cursor-pointer"
            >
              Paramètres
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
