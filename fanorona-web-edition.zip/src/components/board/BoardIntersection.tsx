/**
 * @file BoardIntersection.tsx
 * Interactive node on the Fanorona board.
 * Positions pieces and click targets with full touch and keyboard accessibility.
 */

import React from "react";
import { toAlgebraic } from "../../game/board/boardGraph";
import { Piece, Position } from "../../game/types/gameTypes";
import { BOARD_SVG_HEIGHT, BOARD_SVG_WIDTH, getCoordinates } from "./BoardGridSvg";
import { PieceStone } from "./PieceStone";

export interface BoardIntersectionProps {
  position: Position;
  piece: Piece | null;
  isSelected: boolean;
  isTargetable: boolean;
  hasCaptureMove: boolean;
  isInCaptureSequence: boolean;
  isCapturableTarget: boolean;
  onClick: (pos: Position) => void;
}

export const BoardIntersection: React.FC<BoardIntersectionProps> = ({
  position,
  piece,
  isSelected,
  isTargetable,
  hasCaptureMove,
  isInCaptureSequence,
  isCapturableTarget,
  onClick,
}) => {
  const coords = getCoordinates(position);
  const leftPercent = (coords.x / BOARD_SVG_WIDTH) * 100;
  const topPercent = (coords.y / BOARD_SVG_HEIGHT) * 100;

  const algebraic = toAlgebraic(position);
  let ariaDescription = `Intersection ${algebraic}`;
  if (piece) {
    ariaDescription += `, pièce ${piece.player === "white" ? "blanche" : "noire"}`;
    if (isSelected) ariaDescription += ", sélectionnée";
  } else if (isTargetable) {
    ariaDescription += hasCaptureMove ? ", destination de capture" : ", destination possible";
  } else {
    ariaDescription += ", vide";
  }

  return (
    <button
      type="button"
      id={`intersection-${position.row}-${position.col}`}
      onClick={() => onClick(position)}
      aria-label={ariaDescription}
      className={`absolute -translate-x-1/2 -translate-y-1/2 w-11 h-11 sm:w-13 sm:h-13 md:w-14 md:h-14 flex items-center justify-center rounded-full transition-all focus:outline-none focus:ring-2 focus:ring-[#d87a38] z-10 ${
        isTargetable ? "cursor-pointer" : piece ? "cursor-pointer" : "cursor-default"
      }`}
      style={{
        left: `${leftPercent}%`,
        top: `${topPercent}%`,
      }}
    >
      {/* Target Destination Indicator */}
      {isTargetable && (
        <div className="relative flex items-center justify-center">
          {hasCaptureMove ? (
            // Capturing move destination: glowing emerald/amber ring
            <div className="relative w-8 h-8 rounded-full border-2 border-[#10b981] bg-[#10b981]/25 flex items-center justify-center animate-pulse shadow-[0_0_12px_rgba(16,185,129,0.7)]">
              <div className="w-2.5 h-2.5 rounded-full bg-[#34d399]" />
            </div>
          ) : (
            // Non-capturing (paika) destination: amber soft dot
            <div className="w-6 h-6 rounded-full border border-[#f59e0b] bg-[#f59e0b]/20 flex items-center justify-center hover:scale-125 transition-transform shadow-[0_0_8px_rgba(245,158,11,0.5)]">
              <div className="w-2 h-2 rounded-full bg-[#fbbf24]" />
            </div>
          )}
        </div>
      )}

      {/* Game Piece */}
      {piece && (
        <div className="w-9 h-9 sm:w-11 sm:h-11 md:w-12 md:h-12 pointer-events-none">
          <PieceStone
            player={piece.player}
            isSelected={isSelected}
            isInCaptureSequence={isInCaptureSequence}
            isCapturableTarget={isCapturableTarget}
          />
        </div>
      )}
    </button>
  );
};
