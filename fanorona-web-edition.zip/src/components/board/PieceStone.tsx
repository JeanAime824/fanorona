/**
 * @file PieceStone.tsx
 * Renders physical river pebble / carved stone Fanorona game pieces.
 * White pieces: Polished Malagasy white marble / quartz.
 * Black pieces: Dark volcanic basalt / obsidian.
 */

import React from "react";
import { Player } from "../../game/types/gameTypes";

export interface PieceStoneProps {
  player: Player;
  isSelected?: boolean;
  isInCaptureSequence?: boolean;
  isCapturableTarget?: boolean;
  size?: number; // percentage or px
}

export const PieceStone: React.FC<PieceStoneProps> = ({
  player,
  isSelected = false,
  isInCaptureSequence = false,
  isCapturableTarget = false,
}) => {
  const isWhite = player === "white";

  return (
    <div
      className={`relative w-full h-full rounded-full transition-transform duration-200 select-none ${
        isSelected ? "scale-115 z-20" : "hover:scale-105"
      }`}
    >
      {/* Selection Glow / Pulse */}
      {isSelected && (
        <div className="absolute -inset-2 rounded-full border-2 border-[#f59e0b] shadow-[0_0_15px_rgba(245,158,11,0.7)] animate-pulse pointer-events-none" />
      )}

      {/* Multiple Capture Sequence Active Aura */}
      {isInCaptureSequence && (
        <div className="absolute -inset-2.5 rounded-full border-2 border-[#10b981] shadow-[0_0_20px_rgba(16,185,129,0.8)] animate-ping opacity-75 pointer-events-none" />
      )}

      {/* Capturable Target Warning Aura */}
      {isCapturableTarget && (
        <div className="absolute -inset-1 rounded-full border-2 border-[#ef4444] shadow-[0_0_12px_rgba(239,68,68,0.6)] animate-pulse pointer-events-none" />
      )}

      {/* Physical Stone Body */}
      {isWhite ? (
        // White Polished Quartz Pebble
        <div
          className="w-full h-full rounded-full shadow-[0_4px_10px_rgba(0,0,0,0.5),inset_0_-3px_5px_rgba(180,160,140,0.6),inset_0_3px_5px_rgba(255,255,255,0.9)] border border-[#ded5c7] flex items-center justify-center overflow-hidden"
          style={{
            background:
              "radial-gradient(circle at 35% 30%, #ffffff 0%, #f4ede2 50%, #d8cab7 90%, #b8a590 100%)",
          }}
        >
          {/* Subtle natural stone specular reflection */}
          <div className="absolute top-1.5 left-2 w-3/5 h-2/5 rounded-full bg-gradient-to-b from-white/70 to-transparent blur-[0.5px] pointer-events-none" />
          {/* Subtle Malagasy concentric stone engraving */}
          <div className="w-1/3 h-1/3 rounded-full border border-[#c4b5a0]/40" />
        </div>
      ) : (
        // Black Volcanic Basalt Stone
        <div
          className="w-full h-full rounded-full shadow-[0_4px_12px_rgba(0,0,0,0.7),inset_0_-2px_4px_rgba(0,0,0,0.9),inset_0_2px_4px_rgba(120,100,90,0.4)] border border-[#3b2a20] flex items-center justify-center overflow-hidden"
          style={{
            background:
              "radial-gradient(circle at 35% 30%, #3a322c 0%, #201a16 45%, #14100d 85%, #0a0806 100%)",
          }}
        >
          {/* Soft rim light highlight */}
          <div className="absolute top-1.5 left-2 w-3/5 h-2/5 rounded-full bg-gradient-to-b from-white/20 to-transparent blur-[0.5px] pointer-events-none" />
          {/* Subtle Malagasy engraved ring */}
          <div className="w-1/3 h-1/3 rounded-full border border-[#4a3a30]/50" />
        </div>
      )}
    </div>
  );
};
