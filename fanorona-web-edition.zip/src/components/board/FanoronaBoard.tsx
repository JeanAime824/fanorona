/**
 * @file FanoronaBoard.tsx
 * Complete responsive Fanorona game board.
 * Combines authentic SVG lattice with interactive pieces, touch targets, and visual feedback.
 */

import React, { useMemo } from "react";
import { isSamePosition } from "../../game/board/boardGraph";
import { GameState, Position } from "../../game/types/gameTypes";
import { BoardGridSvg } from "./BoardGridSvg";
import { BoardIntersection } from "./BoardIntersection";

export interface FanoronaBoardProps {
  gameState: GameState;
  targetablePositions: Position[];
  onSelectPosition: (pos: Position) => void;
  showCoordinates?: boolean;
}

export const FanoronaBoard: React.FC<FanoronaBoardProps> = ({
  gameState,
  targetablePositions,
  onSelectPosition,
}) => {
  const { board, selectedPosition, captureSequence, legalMoves } = gameState;

  // Determine which targetable moves produce captures
  const captureTargets = useMemo(() => {
    const set = new Set<string>();
    const activeFrom = captureSequence
      ? captureSequence.piecePosition
      : selectedPosition;

    if (!activeFrom) return set;

    legalMoves.forEach((m) => {
      if (isSamePosition(m.from, activeFrom) && m.captures.length > 0) {
        set.add(`${m.to.row},${m.to.col}`);
      }
    });
    return set;
  }, [legalMoves, captureSequence, selectedPosition]);

  return (
    <div className="relative w-full max-w-4xl mx-auto select-none">
      {/* Board Frame with Malagasy Wood & Stone Inlay */}
      <div className="relative w-full bg-[#20140c] rounded-3xl p-3 sm:p-5 shadow-2xl border-4 border-[#3d2416] shadow-black/80">
        {/* Subtle Carved Inner Bevel */}
        <div className="relative w-full aspect-[920/440] bg-gradient-to-br from-[#29190f] via-[#1d1109] to-[#160c07] rounded-2xl overflow-hidden border border-[#52331c]/50 shadow-[inset_0_2px_15px_rgba(0,0,0,0.8)]">
          {/* Subtle Wood Grain Pattern */}
          <div className="absolute inset-0 bg-board-wood opacity-40 pointer-events-none" />

          {/* SVG Lattice Lines */}
          <BoardGridSvg />

          {/* 45 Interactive Intersection Nodes */}
          <div className="absolute inset-0">
            {board.map((row, r) =>
              row.map((piece, c) => {
                const pos: Position = { row: r, col: c };
                const isSelected = isSamePosition(selectedPosition, pos);
                const isTargetable = targetablePositions.some((tp) =>
                  isSamePosition(tp, pos)
                );
                const hasCapture = captureTargets.has(`${r},${c}`);
                const inChain =
                  captureSequence !== null &&
                  isSamePosition(captureSequence.piecePosition, pos);

                return (
                  <BoardIntersection
                    key={`cell-${r}-${c}`}
                    position={pos}
                    piece={piece}
                    isSelected={isSelected}
                    isTargetable={isTargetable}
                    hasCaptureMove={hasCapture}
                    isInCaptureSequence={inChain}
                    isCapturableTarget={false}
                    onClick={onSelectPosition}
                  />
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
