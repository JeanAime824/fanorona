/**
 * @file BoardGridSvg.tsx
 * Pure SVG rendering of the authentic 9x5 Fanorona geometric board lattice.
 * Renders all horizontal, vertical, and alternating diagonal lines.
 */

import React, { useMemo } from "react";
import { areNeighbors, BOARD_COLS, BOARD_ROWS, hasDiagonalConnections } from "../../game/board/boardGraph";
import { Position } from "../../game/types/gameTypes";

export const BOARD_SVG_WIDTH = 920;
export const BOARD_SVG_HEIGHT = 440;
export const MARGIN_X = 60;
export const MARGIN_Y = 40;
export const CELL_WIDTH = (BOARD_SVG_WIDTH - 2 * MARGIN_X) / (BOARD_COLS - 1); // 100
export const CELL_HEIGHT = (BOARD_SVG_HEIGHT - 2 * MARGIN_Y) / (BOARD_ROWS - 1); // 90

export function getCoordinates(pos: Position): { x: number; y: number } {
  return {
    x: MARGIN_X + pos.col * CELL_WIDTH,
    y: MARGIN_Y + pos.row * CELL_HEIGHT,
  };
}

export const BoardGridSvg: React.FC = () => {
  // Precompute all unique line segments based on graph connections
  const lineSegments = useMemo(() => {
    const lines: Array<{
      x1: number;
      y1: number;
      x2: number;
      y2: number;
      isDiagonal: boolean;
      key: string;
    }> = [];

    for (let r1 = 0; r1 < BOARD_ROWS; r1++) {
      for (let c1 = 0; c1 < BOARD_COLS; c1++) {
        const p1: Position = { row: r1, col: c1 };
        const coord1 = getCoordinates(p1);

        for (let r2 = 0; r2 < BOARD_ROWS; r2++) {
          for (let c2 = 0; c2 < BOARD_COLS; c2++) {
            // Avoid duplicate lines by enforcing order
            if (r1 < r2 || (r1 === r2 && c1 < c2)) {
              const p2: Position = { row: r2, col: c2 };
              if (areNeighbors(p1, p2)) {
                const coord2 = getCoordinates(p2);
                const isDiagonal = r1 !== r2 && c1 !== c2;
                lines.push({
                  x1: coord1.x,
                  y1: coord1.y,
                  x2: coord2.x,
                  y2: coord2.y,
                  isDiagonal,
                  key: `${r1},${c1}-${r2},${c2}`,
                });
              }
            }
          }
        }
      }
    }
    return lines;
  }, []);

  const colLetters = ["A", "B", "C", "D", "E", "F", "G", "H", "I"];
  const rowNumbers = ["5", "4", "3", "2", "1"];

  return (
    <svg
      viewBox={`0 0 ${BOARD_SVG_WIDTH} ${BOARD_SVG_HEIGHT}`}
      className="w-full h-full select-none pointer-events-none"
    >
      <defs>
        {/* Subtle wood shadow */}
        <filter id="woodCarve" x="-5%" y="-5%" width="110%" height="110%">
          <feDropShadow dx="0" dy="1" stdDeviation="0.8" floodColor="#000000" floodOpacity="0.8" />
        </filter>
        {/* Linear gradient for lines */}
        <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#87532d" />
          <stop offset="50%" stopColor="#a36639" />
          <stop offset="100%" stopColor="#87532d" />
        </linearGradient>
      </defs>

      {/* Outer board inlay frame */}
      <rect
        x={MARGIN_X - 16}
        y={MARGIN_Y - 16}
        width={BOARD_SVG_WIDTH - 2 * MARGIN_X + 32}
        height={BOARD_SVG_HEIGHT - 2 * MARGIN_Y + 32}
        rx="12"
        fill="none"
        stroke="#4a2e1b"
        strokeWidth="2"
        opacity="0.6"
      />

      {/* Board Graph Line Segments */}
      <g filter="url(#woodCarve)">
        {lineSegments.map((seg) => (
          <line
            key={seg.key}
            x1={seg.x1}
            y1={seg.y1}
            x2={seg.x2}
            y2={seg.y2}
            stroke="url(#lineGrad)"
            strokeWidth={seg.isDiagonal ? "2.2" : "2.8"}
            strokeLinecap="round"
            opacity={seg.isDiagonal ? "0.85" : "0.95"}
          />
        ))}
      </g>

      {/* Intersection Node Marks */}
      {Array.from({ length: BOARD_ROWS }).map((_, r) =>
        Array.from({ length: BOARD_COLS }).map((_, c) => {
          const coords = getCoordinates({ row: r, col: c });
          const isCenter = r === 2 && c === 4;
          const isStrong = hasDiagonalConnections({ row: r, col: c });

          return (
            <g key={`node-${r}-${c}`}>
              {/* Subtle decorative ring for strong intersections */}
              {isStrong && (
                <circle
                  cx={coords.x}
                  cy={coords.y}
                  r="7"
                  fill="none"
                  stroke="#b8652e"
                  strokeWidth="1"
                  opacity="0.35"
                />
              )}
              {/* Center point distinctive emblem */}
              {isCenter && (
                <circle
                  cx={coords.x}
                  cy={coords.y}
                  r="12"
                  fill="none"
                  stroke="#d87a38"
                  strokeWidth="1.5"
                  strokeDasharray="3,3"
                  opacity="0.6"
                />
              )}
              {/* Node Center Dot */}
              <circle
                cx={coords.x}
                cy={coords.y}
                r={isCenter ? "3.5" : "2.5"}
                fill={isCenter ? "#d87a38" : "#8c5631"}
              />
            </g>
          );
        })
      )}

      {/* Coordinate Labels */}
      {/* Columns: A-I */}
      {colLetters.map((letter, c) => {
        const x = MARGIN_X + c * CELL_WIDTH;
        return (
          <React.Fragment key={`col-label-${c}`}>
            <text
              x={x}
              y={MARGIN_Y - 24}
              textAnchor="middle"
              className="text-[12px] font-semibold fill-[#8a6b52] select-none"
            >
              {letter}
            </text>
            <text
              x={x}
              y={BOARD_SVG_HEIGHT - MARGIN_Y + 30}
              textAnchor="middle"
              className="text-[12px] font-semibold fill-[#8a6b52] select-none"
            >
              {letter}
            </text>
          </React.Fragment>
        );
      })}

      {/* Rows: 1-5 */}
      {rowNumbers.map((num, r) => {
        const y = MARGIN_Y + r * CELL_HEIGHT + 4;
        return (
          <React.Fragment key={`row-label-${r}`}>
            <text
              x={MARGIN_X - 30}
              y={y}
              textAnchor="middle"
              className="text-[12px] font-semibold fill-[#8a6b52] select-none"
            >
              {num}
            </text>
            <text
              x={BOARD_SVG_WIDTH - MARGIN_X + 30}
              y={y}
              textAnchor="middle"
              className="text-[12px] font-semibold fill-[#8a6b52] select-none"
            >
              {num}
            </text>
          </React.Fragment>
        );
      })}
    </svg>
  );
};
