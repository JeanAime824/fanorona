/**
 * @file Navbar.tsx
 * Top navigation bar with Malagasy cultural branding and tab links.
 */

import { BookOpen, Compass, Gamepad2, Settings as SettingsIcon, Volume2, VolumeX } from "lucide-react";
import React from "react";
import { IconButton } from "../ui/IconButton";

export type NavTab = "game" | "rules" | "history" | "settings";

export interface NavbarProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  soundEnabled,
  onToggleSound,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-[#1c110a]/90 backdrop-blur-md border-b border-[#3b2517]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Brand Logo */}
        <button
          type="button"
          onClick={() => onSelectTab("game")}
          className="flex items-center gap-3 cursor-pointer group text-left focus:outline-none"
        >
          {/* Fanorona Lattice Icon */}
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#b8652e] to-[#703612] flex items-center justify-center shadow-md border border-[#d87a38]/40 group-hover:scale-105 transition-transform">
            <div className="w-5 h-5 relative flex items-center justify-center">
              <div className="absolute inset-0 border border-[#f5ede2]/80 rotate-45" />
              <div className="w-2 h-2 rounded-full bg-[#fff8f2] shadow-xs" />
            </div>
          </div>

          <div>
            <div className="text-lg font-black font-display tracking-widest text-[#f5ede2] leading-none">
              FANORONA
            </div>
            <div className="text-[10px] tracking-wider text-[#b89578] uppercase font-medium mt-0.5">
              Madagascar
            </div>
          </div>
        </button>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 sm:gap-2">
          <button
            type="button"
            onClick={() => onSelectTab("game")}
            className={`px-3 py-1.5 sm:px-4 sm:py-2 rounded-xl text-xs sm:text-sm font-medium transition-all flex items-center gap-1.5 cursor-pointer ${
              currentTab === "game"
                ? "bg-[#382215] text-[#f5ede2] border border-[#5c3a22] shadow-sm"
                : "text-[#a69280] hover:text-[#f5ede2] hover:bg-[#29170e]"
            }`}
          >
            <Gamepad2 className="w-4 h-4 text-[#d87a38]" />
            <span>Jouer</span>
          </button>

          <button
            type="button"
            onClick={() => onSelectTab("rules")}
            className={`px-3 py-1.5 sm:px-4 sm:py-2 rounded-xl text-xs sm:text-sm font-medium transition-all flex items-center gap-1.5 cursor-pointer ${
              currentTab === "rules"
                ? "bg-[#382215] text-[#f5ede2] border border-[#5c3a22] shadow-sm"
                : "text-[#a69280] hover:text-[#f5ede2] hover:bg-[#29170e]"
            }`}
          >
            <BookOpen className="w-4 h-4 text-[#d87a38]" />
            <span>Règles</span>
          </button>

          <button
            type="button"
            onClick={() => onSelectTab("history")}
            className={`px-3 py-1.5 sm:px-4 sm:py-2 rounded-xl text-xs sm:text-sm font-medium transition-all flex items-center gap-1.5 cursor-pointer hidden md:flex ${
              currentTab === "history"
                ? "bg-[#382215] text-[#f5ede2] border border-[#5c3a22] shadow-sm"
                : "text-[#a69280] hover:text-[#f5ede2] hover:bg-[#29170e]"
            }`}
          >
            <Compass className="w-4 h-4 text-[#d87a38]" />
            <span>Histoire</span>
          </button>

          <button
            type="button"
            onClick={() => onSelectTab("settings")}
            className={`px-3 py-1.5 sm:px-4 sm:py-2 rounded-xl text-xs sm:text-sm font-medium transition-all flex items-center gap-1.5 cursor-pointer ${
              currentTab === "settings"
                ? "bg-[#382215] text-[#f5ede2] border border-[#5c3a22] shadow-sm"
                : "text-[#a69280] hover:text-[#f5ede2] hover:bg-[#29170e]"
            }`}
          >
            <SettingsIcon className="w-4 h-4 text-[#d87a38]" />
            <span className="hidden sm:inline">Paramètres</span>
          </button>

          {/* Quick Sound Toggle */}
          <div className="ml-2 pl-2 border-l border-[#3b2517]">
            <IconButton
              size="sm"
              variant="ghost"
              label={soundEnabled ? "Couper le son" : "Activer le son"}
              icon={
                soundEnabled ? (
                  <Volume2 className="w-4 h-4 text-[#d87a38]" />
                ) : (
                  <VolumeX className="w-4 h-4 text-[#8a7260]" />
                )
              }
              onClick={onToggleSound}
            />
          </div>
        </nav>
      </div>
    </header>
  );
};
