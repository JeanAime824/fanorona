/**
 * @file GameStatusPanel.tsx
 * Displays active player, remaining pieces, game progress, and quick action buttons.
 */

import { Bot, CheckCircle2, ChevronRight, User } from "lucide-react";
import React from "react";
import { countPieces } from "../../game/board/initialBoard";
import { GameState } from "../../game/types/gameTypes";
import { formatDifficulty, formatPlayerName, getStatusInstruction } from "../../utils/formatters";
import { Badge } from "../ui/Badge";
import { Button } from "../ui/Button";

export interface GameStatusPanelProps {
  gameState: GameState;
  isAiThinking: boolean;
  onEndTurn: () => void;
}

export const GameStatusPanel: React.FC<GameStatusPanelProps> = ({
  gameState,
  isAiThinking,
  onEndTurn,
}) => {
  const {
    currentPlayer,
    status,
    winner,
    gameMode,
    difficulty,
    aiPlayerColor,
    captureSequence,
    mandatoryCaptureActive,
    turnNumber,
  } = gameState;

  const pieceCounts = countPieces(gameState.board);
  const isWhite = currentPlayer === "white";
  const inChain = captureSequence !== null;

  const statusText = getStatusInstruction(
    status,
    winner,
    currentPlayer,
    isAiThinking,
    inChain,
    mandatoryCaptureActive
  );

  return (
    <div className="w-full bg-[#22160f] border border-[#452b1b] rounded-2xl p-4 sm:p-5 shadow-xl shadow-black/40">
      {/* Top row: Players & Score */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        {/* White Player Card */}
        <div
          className={`p-3 rounded-xl border transition-all duration-200 flex items-center justify-between ${
            isWhite && status === "playing"
              ? "bg-[#2e1d13] border-[#d87a38] shadow-md shadow-[#d87a38]/10 ring-1 ring-[#d87a38]/40"
              : "bg-[#1a100a] border-[#362114] opacity-80"
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-full bg-[#f4ede2] border border-[#d8cab7] shadow-xs shrink-0 flex items-center justify-center">
              <div className="w-2 h-2 rounded-full bg-[#b8a590]" />
            </div>
            <div>
              <div className="text-xs text-[#a89582] flex items-center gap-1 font-medium">
                {gameMode === "ai" && aiPlayerColor === "white" ? (
                  <>
                    <Bot className="w-3 h-3 text-[#d87a38]" /> IA
                  </>
                ) : (
                  <>
                    <User className="w-3 h-3 text-[#f4efe8]" /> Joueur
                  </>
                )}
              </div>
              <div className="text-sm font-bold text-[#f4efe8]">Blancs</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-xl font-display font-extrabold text-[#f4efe8]">
              {pieceCounts.white}
            </div>
            <div className="text-[10px] uppercase tracking-wider text-[#8a7260]">
              pièces
            </div>
          </div>
        </div>

        {/* Black Player Card */}
        <div
          className={`p-3 rounded-xl border transition-all duration-200 flex items-center justify-between ${
            !isWhite && status === "playing"
              ? "bg-[#2e1d13] border-[#d87a38] shadow-md shadow-[#d87a38]/10 ring-1 ring-[#d87a38]/40"
              : "bg-[#1a100a] border-[#362114] opacity-80"
          }`}
        >
          <div className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-full bg-[#241c17] border border-[#4a3a30] shadow-xs shrink-0 flex items-center justify-center">
              <div className="w-2 h-2 rounded-full bg-[#110d0b]" />
            </div>
            <div>
              <div className="text-xs text-[#a89582] flex items-center gap-1 font-medium">
                {gameMode === "ai" && aiPlayerColor === "black" ? (
                  <>
                    <Bot className="w-3 h-3 text-[#d87a38]" /> IA
                  </>
                ) : (
                  <>
                    <User className="w-3 h-3 text-[#f4efe8]" /> Joueur
                  </>
                )}
              </div>
              <div className="text-sm font-bold text-[#f4efe8]">Noirs</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-xl font-display font-extrabold text-[#f4efe8]">
              {pieceCounts.black}
            </div>
            <div className="text-[10px] uppercase tracking-wider text-[#8a7260]">
              pièces
            </div>
          </div>
        </div>
      </div>

      {/* Middle row: Badges & Status instructions */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <Badge variant="neutral" size="sm">
            Tour {turnNumber}
          </Badge>
          {gameMode === "ai" && (
            <Badge variant="primary" size="sm">
              IA {formatDifficulty(difficulty)}
            </Badge>
          )}
          {mandatoryCaptureActive && !inChain && (
            <Badge variant="warning" size="sm">
              Capture requise
            </Badge>
          )}
          {inChain && (
            <Badge variant="success" size="sm">
              Séquence : +{captureSequence.capturesCount} capture(s)
            </Badge>
          )}
        </div>

        {/* Voluntary End Turn button if in multiple capture chain */}
        {inChain && status === "playing" && (
          <Button
            size="sm"
            variant="primary"
            onClick={onEndTurn}
            icon={<CheckCircle2 className="w-4 h-4" />}
          >
            Terminer le tour
          </Button>
        )}
      </div>

      {/* Instruction text banner */}
      <div className="p-2.5 rounded-xl bg-[#170e08] border border-[#382315] text-xs text-[#d1bfad] flex items-center gap-2">
        <ChevronRight className="w-4 h-4 text-[#d87a38] shrink-0" />
        <span className="leading-snug">{statusText}</span>
      </div>
    </div>
  );
};
