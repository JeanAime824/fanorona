/**
 * @file NewGameModal.tsx
 * Dialog allowing configuration of game mode, AI difficulty, and starting player color.
 */

import { Bot, Play, Sparkles, User, Users } from "lucide-react";
import React, { useState } from "react";
import { AiDifficulty, GameMode, Player } from "../../game/types/gameTypes";
import { Button } from "../ui/Button";
import { Modal } from "../ui/Modal";

export interface NewGameModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartGame: (mode: GameMode, difficulty: AiDifficulty, playerColor: Player) => void;
  initialDifficulty?: AiDifficulty;
}

export const NewGameModal: React.FC<NewGameModalProps> = ({
  isOpen,
  onClose,
  onStartGame,
  initialDifficulty = "medium",
}) => {
  const [selectedMode, setSelectedMode] = useState<GameMode>("ai");
  const [selectedDifficulty, setSelectedDifficulty] = useState<AiDifficulty>(initialDifficulty);
  const [selectedColor, setSelectedColor] = useState<Player>("white");

  if (!isOpen) return null;

  const handleStart = () => {
    // If player chooses White in AI mode, AI plays Black; and vice versa
    const aiColor: Player = selectedColor === "white" ? "black" : "white";
    onStartGame(selectedMode, selectedDifficulty, aiColor);
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Configurer une nouvelle partie"
      maxWidth="md"
    >
      <div className="space-y-5">
        {/* Mode selection */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-[#9e8874] mb-2">
            Mode de jeu
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setSelectedMode("ai")}
              className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1.5 focus:outline-none focus:ring-2 focus:ring-[#d87a38] ${
                selectedMode === "ai"
                  ? "bg-[#332014] border-[#d87a38] shadow-md shadow-[#d87a38]/10"
                  : "bg-[#1c110a] border-[#382315] opacity-70 hover:opacity-100"
              }`}
            >
              <div className="flex items-center gap-2 text-sm font-bold text-[#f4efe8]">
                <Bot className="w-4 h-4 text-[#d87a38]" />
                <span>Contre l'IA</span>
              </div>
              <p className="text-xs text-[#a69280]">
                Affrontez l'algorithme Minimax Alpha-Beta.
              </p>
            </button>

            <button
              type="button"
              onClick={() => setSelectedMode("pvp")}
              className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1.5 focus:outline-none focus:ring-2 focus:ring-[#d87a38] ${
                selectedMode === "pvp"
                  ? "bg-[#332014] border-[#d87a38] shadow-md shadow-[#d87a38]/10"
                  : "bg-[#1c110a] border-[#382315] opacity-70 hover:opacity-100"
              }`}
            >
              <div className="flex items-center gap-2 text-sm font-bold text-[#f4efe8]">
                <Users className="w-4 h-4 text-[#d87a38]" />
                <span>2 Joueurs (Pass & Play)</span>
              </div>
              <p className="text-xs text-[#a69280]">
                Jouez à tour de rôle sur le même appareil.
              </p>
            </button>
          </div>
        </div>

        {/* AI Difficulty (if AI mode) */}
        {selectedMode === "ai" && (
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-[#9e8874] mb-2">
              Niveau de difficulté
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  { id: "easy", label: "Facile", desc: "Idéal pour débuter" },
                  { id: "medium", label: "Moyen", desc: "Minimax 2 coups" },
                  { id: "hard", label: "Difficile", desc: "Minimax 3 coups optimisé" },
                ] as const
              ).map((d) => (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => setSelectedDifficulty(d.id)}
                  className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#d87a38] ${
                    selectedDifficulty === d.id
                      ? "bg-[#382215] border-[#d87a38] text-[#f4efe8] shadow-sm"
                      : "bg-[#1c110a] border-[#382315] text-[#a69280] hover:text-[#f4efe8]"
                  }`}
                >
                  <div className="text-xs font-bold">{d.label}</div>
                  <div className="text-[10px] text-[#85705e] mt-0.5">{d.desc}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Player color choice */}
        <div>
          <label className="block text-xs font-semibold uppercase tracking-wider text-[#9e8874] mb-2">
            Votre couleur
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setSelectedColor("white")}
              className={`p-3 rounded-xl border flex items-center gap-3 transition-all cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#d87a38] ${
                selectedColor === "white"
                  ? "bg-[#332014] border-[#d87a38]"
                  : "bg-[#1c110a] border-[#382315] opacity-70 hover:opacity-100"
              }`}
            >
              <div className="w-5 h-5 rounded-full bg-[#f4ede2] border border-[#d8cab7] shadow-xs" />
              <div className="text-left">
                <div className="text-xs font-bold text-[#f4efe8]">Blancs</div>
                <div className="text-[10px] text-[#8a7260]">Joue en 1er</div>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setSelectedColor("black")}
              className={`p-3 rounded-xl border flex items-center gap-3 transition-all cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#d87a38] ${
                selectedColor === "black"
                  ? "bg-[#332014] border-[#d87a38]"
                  : "bg-[#1c110a] border-[#382315] opacity-70 hover:opacity-100"
              }`}
            >
              <div className="w-5 h-5 rounded-full bg-[#201813] border border-[#4a3a30] shadow-xs" />
              <div className="text-left">
                <div className="text-xs font-bold text-[#f4efe8]">Noirs</div>
                <div className="text-[10px] text-[#8a7260]">Joue en 2nd</div>
              </div>
            </button>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#382315]">
          <Button variant="ghost" size="md" onClick={onClose}>
            Annuler
          </Button>
          <Button
            variant="primary"
            size="md"
            onClick={handleStart}
            icon={<Play className="w-4 h-4 fill-current" />}
          >
            Lancer la partie
          </Button>
        </div>
      </div>
    </Modal>
  );
};
