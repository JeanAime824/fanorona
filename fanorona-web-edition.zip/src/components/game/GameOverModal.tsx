/**
 * @file GameOverModal.tsx
 * Dialog presented upon victory, defeat, or draw.
 */

import { RefreshCw, Trophy, Users } from "lucide-react";
import React from "react";
import { GameState } from "../../game/types/gameTypes";
import { Button } from "../ui/Button";
import { Modal } from "../ui/Modal";

export interface GameOverModalProps {
  gameState: GameState;
  isOpen: boolean;
  onRestart: () => void;
  onClose: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  gameState,
  isOpen,
  onRestart,
  onClose,
}) => {
  if (!isOpen || gameState.status !== "game_over") return null;

  const { winner, gameMode, aiPlayerColor, turnNumber, capturedPieces } = gameState;

  let title = "Fin de la partie";
  let subtitle = "";
  let isWin = false;

  if (winner === "draw") {
    title = "Match Nul";
    subtitle = "Aucun des deux camps ne peut forcer la victoire.";
  } else if (gameMode === "ai") {
    if (winner === aiPlayerColor) {
      title = "Défaite";
      subtitle = "L'intelligence artificielle a remporté la partie.";
    } else {
      title = "Victoire !";
      subtitle = "Félicitations ! Vous avez vaincu l'IA.";
      isWin = true;
    }
  } else {
    title = `Victoire des ${winner === "white" ? "Blancs" : "Noirs"} !`;
    subtitle = `Le joueur ${winner === "white" ? "Blanc" : "Noir"} a capturé ou bloqué toutes les pièces adverses.`;
    isWin = true;
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} maxWidth="sm" hideCloseButton={false}>
      <div className="text-center py-2">
        {/* Trophy / Icon */}
        <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-[#362114] border border-[#5a3821] flex items-center justify-center shadow-lg shadow-black/50">
          <Trophy
            className={`w-8 h-8 ${
              isWin ? "text-[#f59e0b] animate-bounce" : "text-[#d87a38]"
            }`}
          />
        </div>

        <h3 className="text-2xl font-bold font-display text-[#f4efe8] mb-1">
          {title}
        </h3>
        <p className="text-xs text-[#a69280] mb-6 px-4">{subtitle}</p>

        {/* Stats Summary */}
        <div className="grid grid-cols-2 gap-3 mb-6 p-3 rounded-xl bg-[#1a100a] border border-[#382315] text-left">
          <div>
            <div className="text-[10px] uppercase text-[#7d6857] font-semibold">
              Tours joués
            </div>
            <div className="text-base font-bold text-[#e6dbcf]">
              {turnNumber}
            </div>
          </div>
          <div>
            <div className="text-[10px] uppercase text-[#7d6857] font-semibold">
              Total captures
            </div>
            <div className="text-base font-bold text-[#e6dbcf]">
              {capturedPieces.white + capturedPieces.black} pièces
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-col gap-2.5">
          <Button
            variant="primary"
            size="md"
            onClick={onRestart}
            icon={<RefreshCw className="w-4 h-4" />}
            className="w-full"
          >
            Rejouer une partie
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="w-full"
          >
            Examiner le plateau
          </Button>
        </div>
      </div>
    </Modal>
  );
};
