/**
 * @file MoveHistoryPanel.tsx
 * Chronological log of moves played in the match with algebraic coordinates and capture details.
 */

import { History, Swords } from "lucide-react";
import React, { useEffect, useRef } from "react";
import { MoveHistoryEntry } from "../../game/types/gameTypes";
import { Badge } from "../ui/Badge";

export interface MoveHistoryPanelProps {
  history: MoveHistoryEntry[];
}

export const MoveHistoryPanel: React.FC<MoveHistoryPanelProps> = ({ history }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history]);

  return (
    <div className="w-full bg-[#22160f] border border-[#452b1b] rounded-2xl p-4 shadow-xl flex flex-col h-64 sm:h-80">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 mb-2 border-b border-[#3b2517]">
        <div className="flex items-center gap-2 text-sm font-bold text-[#f4efe8]">
          <History className="w-4 h-4 text-[#d87a38]" />
          <span>Historique des coups</span>
        </div>
        <span className="text-xs text-[#8a7260]">
          {history.length} coup{history.length !== 1 ? "s" : ""}
        </span>
      </div>

      {/* Moves list */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto space-y-1.5 pr-1 scrollbar-thin scrollbar-thumb-[#452b1b]"
      >
        {history.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-xs text-[#7d6857] italic">
            Aucun coup joué pour le moment.
          </div>
        ) : (
          history.map((record, idx) => {
            const isCapture = record.captures.length > 0;
            const isWhite = record.player === "white";

            return (
              <div
                key={record.id || idx}
                className="flex items-center justify-between p-2 rounded-lg bg-[#1a100a]/70 border border-[#331f13] text-xs hover:bg-[#26170e] transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="text-[#6e5849] font-mono w-5">
                    {idx + 1}.
                  </span>
                  <div
                    className={`w-3 h-3 rounded-full border shrink-0 ${
                      isWhite
                        ? "bg-[#f4ede2] border-[#ded5c7]"
                        : "bg-[#201813] border-[#4a3a30]"
                    }`}
                  />
                  <span className="font-mono font-medium text-[#e8ded3]">
                    {record.notation}
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {isCapture ? (
                    <Badge variant="primary" size="sm">
                      <Swords className="w-2.5 h-2.5" />
                      <span>
                        {record.captureType === "approach" ? "Tomboky" : "Faly"} (+
                        {record.captures.length})
                      </span>
                    </Badge>
                  ) : (
                    <span className="text-[10px] text-[#85705e] uppercase">
                      Paika
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
