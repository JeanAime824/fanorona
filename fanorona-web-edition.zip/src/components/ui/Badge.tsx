/**
 * @file Badge.tsx
 * Design system Badge / Pill component.
 */

import React from "react";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  variant?: "neutral" | "primary" | "success" | "warning" | "danger";
  size?: "sm" | "md";
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = "neutral",
  size = "md",
  className = "",
  ...props
}) => {
  const sizeStyles = {
    sm: "px-2 py-0.5 text-xs font-medium",
    md: "px-2.5 py-1 text-xs font-semibold tracking-wide",
  };

  const variantStyles = {
    neutral: "bg-[#2c1d13] text-[#cfbda9] border border-[#4a3222]",
    primary: "bg-[#b8652e]/20 text-[#f5a164] border border-[#b8652e]/40",
    success: "bg-[#1b432a]/30 text-[#86efac] border border-[#22c55e]/30",
    warning: "bg-[#523311]/40 text-[#fcd34d] border border-[#f59e0b]/30",
    danger: "bg-[#591616]/30 text-[#fca5a5] border border-[#ef4444]/30",
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full whitespace-nowrap select-none ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
      {...props}
    >
      {children}
    </span>
  );
};
