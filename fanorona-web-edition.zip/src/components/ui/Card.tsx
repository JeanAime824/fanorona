/**
 * @file Card.tsx
 * Design system card with warm Malagasy stone/wood accents.
 */

import React from "react";

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: "default" | "elevated" | "accent";
}

export const Card: React.FC<CardProps> = ({
  children,
  variant = "default",
  className = "",
  ...props
}) => {
  const variantStyles = {
    default: "bg-[#20150e]/90 border border-[#3d2719]",
    elevated: "bg-[#251911] border border-[#4a3020] shadow-xl shadow-black/40",
    accent: "bg-[#291b12] border border-[#b8652e]/30 shadow-lg shadow-[#b8652e]/5",
  };

  return (
    <div
      className={`rounded-2xl p-5 ${variantStyles[variant]} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
};
