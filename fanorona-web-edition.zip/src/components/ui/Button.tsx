/**
 * @file Button.tsx
 * Reusable design system Button component.
 */

import React from "react";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "danger" | "outline" | "ghost";
  size?: "sm" | "md" | "lg";
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = "primary",
  size = "md",
  icon,
  className = "",
  disabled,
  ...props
}) => {
  const baseStyles =
    "inline-flex items-center justify-center font-medium tracking-wide rounded-xl transition-all duration-150 select-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#d87a38] disabled:opacity-40 disabled:cursor-not-allowed active:scale-[0.98]";

  const sizeStyles = {
    sm: "px-3 py-1.5 text-xs gap-1.5",
    md: "px-5 py-2.5 text-sm gap-2",
    lg: "px-6 py-3.5 text-base gap-2.5 font-semibold",
  };

  const variantStyles = {
    primary:
      "bg-gradient-to-b from-[#b8652e] to-[#8f471a] text-[#fff8f2] shadow-md hover:from-[#c97136] hover:to-[#9e4f1e] border border-[#d87a38]/40 shadow-[#8f471a]/20",
    secondary:
      "bg-[#2d1e15] hover:bg-[#3d2a1e] text-[#f4efe8] border border-[#523724] shadow-sm",
    danger:
      "bg-gradient-to-b from-[#942727] to-[#711c1c] text-[#fee2e2] hover:from-[#a72e2e] hover:to-[#822121] border border-[#b93838]/40 shadow-sm",
    outline:
      "bg-transparent hover:bg-[#2d1e15] text-[#e0cfbe] border border-[#523724]",
    ghost:
      "bg-transparent hover:bg-[#2d1e15]/70 text-[#c2b09f] hover:text-[#fff8f2]",
  };

  return (
    <button
      className={`${baseStyles} ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
      disabled={disabled}
      {...props}
    >
      {icon && <span className="shrink-0">{icon}</span>}
      <span className="whitespace-nowrap">{children}</span>
    </button>
  );
};
