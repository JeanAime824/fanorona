/**
 * @file IconButton.tsx
 * Accessible icon button for game controls and toolbars.
 */

import React from "react";

export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  icon: React.ReactNode;
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
}

export const IconButton: React.FC<IconButtonProps> = ({
  label,
  icon,
  variant = "secondary",
  size = "md",
  className = "",
  disabled,
  ...props
}) => {
  const sizeStyles = {
    sm: "w-8 h-8 text-xs",
    md: "w-10 h-10 text-sm",
    lg: "w-12 h-12 text-base",
  };

  const variantStyles = {
    primary:
      "bg-[#b8652e] hover:bg-[#c97136] text-white border border-[#d87a38]/40 shadow-sm",
    secondary:
      "bg-[#2d1e15] hover:bg-[#3d2a1e] text-[#e0cfbe] border border-[#523724]",
    ghost:
      "bg-transparent hover:bg-[#2d1e15] text-[#b3a190] hover:text-[#fff8f2]",
    danger:
      "bg-[#5c1c1c] hover:bg-[#732222] text-[#fca5a5] border border-[#852727]",
  };

  return (
    <button
      aria-label={label}
      title={label}
      disabled={disabled}
      className={`inline-flex items-center justify-center rounded-xl transition-all duration-150 select-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-[#d87a38] disabled:opacity-30 disabled:cursor-not-allowed active:scale-95 ${sizeStyles[size]} ${variantStyles[variant]} ${className}`}
      {...props}
    >
      {icon}
    </button>
  );
};
